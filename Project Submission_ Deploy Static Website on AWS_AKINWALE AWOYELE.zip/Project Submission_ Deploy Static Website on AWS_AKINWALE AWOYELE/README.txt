Deploy Static Website on AWS

Cloud Front domain name URL >> d2x4p9xlzgtv2p.cloudfront.net

Website-endpoint URL >> http://papy-486282965277-bucket.s3-website-us-east-1.amazonaws.com/